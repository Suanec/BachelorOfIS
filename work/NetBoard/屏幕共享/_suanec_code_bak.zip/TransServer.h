﻿/*
 2014 12 29
 By BOBO
 FILE Trans By TCP /WINDOWS
*/
#ifndef _TRANSSERVER_H
#define _TRANSSERVER_H
//#define DEBUGOUT_LOG
#define DEBUG_START


#include <netinet/in.h>    // for sockaddr_in
#include <sys/types.h>     // for socket
#include <sys/socket.h>    // for socket
#include <stdio.h>         // for printf
#include <stdlib.h>        // for exit
#include <string.h>        // for bzero
#include <stdarg.h>		   // fro printline

#include <errno.h>
#include <sys/wait.h>
#include <unistd.h>
#include <arpa/inet.h>

#include <string>
#include "SocketManager.h"
/*
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
*/
#define SERVER_PORT   	12308
#define DEFAULT_BUFLEN 	1024        ///  suanec
#define DEFAULT_DIRLEN 	256
#define CHUNK_SIZE	   	102400		//分块发送大小100K
#define SOCK_LISTENLEN  50
#define TIMEOUT_WAIT    1
#define RETRY_TIMES     3

class TransServer{
public:
	enum RunMode {
		Off,
		Free,
		Wrok,
	};
	TransServer();
	virtual ~TransServer();
	virtual bool init(bool tcp = true);
	virtual bool closeConn();

public:
	virtual void run();
	//virtual bool fileTrans(const std::string &fileName,char* fromIp);/*****/
	//virtual bool fileTrans(const std::string &filePath);/*接收文件*/
	virtual bool transEnd();
	virtual void ScreenTrans( SocketManager * );///  suanec 主屏数据接收转发函数
	virtual int sock()
	{ return m_sock;}
private:
	static  void errorLine(const char* str);
	static  void printLine(const char *format,...);
	static  void*recvFile(void *clientSock);//接收线程
	static  void*downLoad(void *clientSock);
	static  void*PicRecv(void * clientSock);///  suanec？？
	static  void*MesRecv(void * clientSock);///  suanec ？？
	static  char*safeRecv(int clientSock,bool (*check)(char*));
	static  void*clientTrans(void* clientSock);
protected:  
	std::string     TargetIP;
	int	    	 	  m_sock;
	int         m_clientSock;
	sockaddr_in	 client_addr;
private: 
	FILE*	m_file;
	std::string	  m_fileName;
private:
    //Media * m_media;
	SocketManager *smag;///  suanec


private:
    //Board * m_board;


private:  //base
	int		m_runStatus;
    int		m_transType;   // file  media whiteboard
	char	m_bufDir[DEFAULT_DIRLEN];
	//	const std::string  m_outBuffer;
	//	const std::string  m_inBuffer;
};

#endif
