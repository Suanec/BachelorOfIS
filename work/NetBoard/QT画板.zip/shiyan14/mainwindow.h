#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include<QMainWindow>

class QAction;
class QMenu;
class QToolBar;
class QImage;
class QPoint;
class QColor;
class QBrush;
class QPen;
class QLabel;
class QToolButton;
class QSpinBox;

class MainWindow:public QMainWindow
{
    Q_OBJECT
public:
    MainWindow();
    void createMenus();
    void createActions();
    void createToolBar();
    enum drawtype{line=1,rect,ellipse,pen,eraser};

public slots:
    void slotNewFile();
    void slotOpenFile();
    void slotSaveFile();

    void slotAbout();
    void drawrects();
    void drawlines();
    void drawellipses();
    void drawpen();
    void draweraser();
    void drawPaletteline();
    void drawPalettefill();
    void drawwidth();



protected:
    bool flag;
    void mousePressEvent(QMouseEvent *);
    void mouseMoveEvent(QMouseEvent *);
    void mouseReleaseEvent(QMouseEvent *);
    void paintEvent(QPaintEvent *);
    void paint(QImage &image);

private:
    QMenu *fileMenu;
    QMenu *editMenu;
    QMenu *aboutMenu;
    QToolBar *fileTool;
    QToolBar *paintTool;
    QAction *OpenAction;
    QAction *NewAction;
    QAction *SaveAction;
    QAction *exitAction;

    QAction *aboutAction;
    QAction *rectAction;
    QAction *lineAction;
    QAction *ellipseAction;
    QAction *penAction;
    QAction *eraserAction;

    QLabel *widthLabel;
    QLabel *fillLabel;
    QLabel *lineLabel;
    QToolButton *lineButton;
    QToolButton *fillButton;
    QSpinBox *spinbox;

    QImage image;
    QImage tempimage;
    QPoint startPoint;
    QPoint endPoint;
    drawtype type ;
    QColor fillcolor;
    QColor linecolor;
    QBrush brush;


    int w;

};

#endif // MAINWINDOW_H
