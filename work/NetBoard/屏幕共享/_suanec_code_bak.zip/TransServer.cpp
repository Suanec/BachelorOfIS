﻿#include "TransServer.h"
#include <pthread.h>
#include <iostream>
#include <string.h>

bool  sqlCheck(char* buf)
{
	if(buf ==NULL)
		return false;
	/*
	 SQL CHECK
	*/
	return true;
}

bool hashCheck(char* buf)
{
	if(buf ==NULL)
		return false;
	/*
	 HASH CHECK
	 * */

	return true;
}


TransServer::TransServer():m_runStatus(Off)
{
	//m_file   = NULL;
	//m_sock   = -1;
	init();
#ifdef DEBUGOUT_LOG
	freopen("Debug.txt", "wa", stdout);
#endif
}

TransServer::~TransServer()
{
	closeConn();
}

bool TransServer::init(bool tcp)
{
	if(m_runStatus!=Off)
		return false;
	///  suanec
	smag = new SocketManager();

	//SOCKET
    struct sockaddr_in server_addr;
	bzero(&server_addr,sizeof(server_addr));
	server_addr.sin_family = AF_INET;
	server_addr.sin_addr.s_addr = htons(INADDR_ANY);
	server_addr.sin_port = htons(SERVER_PORT);
	m_sock = socket(PF_INET,SOCK_STREAM,0);
	if(m_sock < 0){
		printLine("Create Socket Failed!");
		return false;
	}else {
		int on =1;
		setsockopt( m_sock, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on) );
	}
	if(bind(m_sock,(struct sockaddr*)&server_addr,sizeof(server_addr)) ){
		printLine("Server Bind Port : %d Failed!", SERVER_PORT);
		return false;
	}
	if(tcp)
	if(listen(m_sock, SOCK_LISTENLEN) ){
		printLine("Server Listen Failed!");
		return false;
	}

	printLine("TRANSSERVER: INIT SUCCESS");
	m_runStatus = Free;
	return true;
}

bool TransServer::closeConn()
{
//	if (m_runStatus != Free)
//		return false;
	close(m_sock);
	m_runStatus = Off;
	return true;
}

void TransServer::run()
{
	socklen_t	length = sizeof(client_addr);
	void * sock;
	pthread_t ScreenTransThread;
	if(pthread_create(&ScreenTransThread,NULL,ScreenTrans,smag) != 0)
	{
		errorLine("ScreenTrans pthread_create Error.");
	}

	while(true)
	{
		bzero(&client_addr,sizeof(client_addr));
		m_clientSock = accept(m_sock,(struct sockaddr*)&client_addr,&length);
		sock = &m_clientSock;
		if(m_clientSock < 0) {
			errorLine("Server Accept Failed!");
			continue;
		}
		printLine("SERVER:HELLO ONE CLIENT ");

		//char * buf = safeRecv(m_clientSock,hashCheck);



		pthread_t thread;
		if(pthread_create(&thread,NULL,clientTrans,sock) != 0) {
			errorLine("pthread_create Error.");
			close(m_clientSock);
		}

	}
}

bool TransServer::transEnd()
{
//	if(m_runStatus==In || m_runStatus==Out)
//		m_runStatus = Free;

	if(m_file)
		fclose(m_file);
	/*if(m_media)
	close(m_media);
	if(m_file)
	close(m_board);*/
	/*
	m_file =NULL;
	m_media =NULL;
	m_board =NULL;*/



	return true;
}


void TransServer::errorLine(const char * str)
{
	if(str) {
	  perror(str);
	//  printf(str);
	}
}

void TransServer::printLine(const char *format,...)
{
#ifdef DEBUG_START
	va_list args;
	va_start(args,format);
	printf(format,args);
	printf("\n");
    va_end(args);
#else
    // send(client_sock,"***",sizeof("***"),0);
    // Message YD; Enque::dispatch(YD);
#endif
}



char* TransServer::safeRecv(int clientSock,bool (*check)(char*))
{
   char* buf=new char[DEFAULT_BUFLEN];
   memset(buf,0,DEFAULT_BUFLEN);
   int   len;
   int 	 sum = RETRY_TIMES;
   while(sum--) 
   { 
	   //GET FILE NAME FROM CLIENT BY SOCK
	   sleep(TIMEOUT_WAIT);
	   len = recv(clientSock,buf,DEFAULT_BUFLEN,0);
	   if(len <1) 
	   {
			errorLine("Saferecv Error.is closed?");
			//send(clientSock,"400",sizeof("400"),0);
			continue;
			/*
			while(len = recv(clientSock,buf,DEFAULT_BUFLEN,0)) {
				buf = realloc(buf,DEFAULT_BUFLEN*(i++));
			}
			*/
		}
		buf[len] = 0;
		if(!check)
			break;
		if(check(buf)/*SQL index the file*/) {
			break;
		}else {
			errorLine("Buf Not Acc Check");
			//send(clientSock,"404",sizeof("404"),0);
		}
		buf[0] = 0;
   }
   return buf;
}
void* TransServer::clientTrans(void* clientSock)
{
	int	client_sock = *(int*)clientSock;
	pthread_t thread;
	char *buf;
	//while(true) {
		buf  = safeRecv(client_sock,hashCheck);
		//should use OBJList change with it
		//if(list.empty())
		//   hungup
		if(buf[0] == 'r') {
			if(pthread_create(&thread,NULL,recvFile,clientSock) != 0) {
				errorLine("recv pthread_create Error.");
			}
			return NULL;//continue;
		}
		if(buf[0] == 'd') {
			if(pthread_create(&thread,NULL,downLoad,clientSock) != 0) {
				errorLine("download pthread_create Error.");
				close(client_sock);
			}
			return NULL;//continue;
		}
		if(buf[0] == 'p') /// picture suanec
		{
			std::string str_Temp;
			int index = 10;
			while( buf[index] != '0' )index++;

			str_Temp.append(i-10,buf[10]);
			SOCKLIST stuc_Temp ;
			memcpy(stuc_Temp.strArr,buf[10],i-10);
			stuc_Temp.m_sock = client_sock;
			stuc_Temp.m_arrlen = i-10;
			stuc_Temp.next = NULL;
			stuc_Temp.thread = 0;
			//if(pthread_create(&thread,NULL,PicRecv,clientSock) != 0) 
			//{
			//	errorLine("download pthread_create Error.");
			//	close(client_sock);
			//}
			
			smag->AddHead(client_sock,str_Temp,0);
			return NULL;//continue;
		}
		if(buf[0] == 'm') /// message suanec
		{
			if(pthread_create(&thread,NULL,MesRecv,clientSock) != 0) {
				errorLine("download pthread_create Error.");
				close(client_sock);
			}
			smag->AddHead(client_sock,buf[10],thread);
			return NULL;//continue;
		}
		if(buf[0] == 0) {
			printLine("Client DisConnect");
			//break;
		}
		printLine("FUN SELECT ERROR WITH:%s From %d",buf,client_sock);
	//}
	close(client_sock);
	delete buf;
	return NULL;
}

void* TransServer::downLoad(void* clientSock)
{
	int			client_sock = *(int*)clientSock;
	std::string fileName = safeRecv(client_sock,sqlCheck);
	FILE*	theFile  = fopen( fileName.c_str(),"r");
	if(!theFile) {
		errorLine("FILE NOT OPEN SUCCESS."); //to client by YDMessage
		close(client_sock);
		return NULL;
	}
printLine("Down Load FIle step:opened file");
	long transPos = 0;
	if(recv(client_sock,(char*)&transPos,sizeof(long),0) < 1)		//接收断点
		printLine("Pos Recv Error.");
printLine("File Trans Currentpos is %l",transPos);
	int	nChunkCount = 0;        //文件块数

	fseek(theFile,0L,SEEK_END);
	long FileFullLen = ftell(theFile) + 1;//获取文件总长度
	fseek(theFile,(long)(transPos),SEEK_SET);
	int FileLen = FileFullLen - transPos;		//剩余文件大小
	if(FileLen == 0) {
		printLine("The file has been sent,Modify the %s.tmp to %s",theFile,theFile); //OUT TO CLIENT BY SOCK
		close(client_sock);
		return false;
	}
	nChunkCount = FileLen / CHUNK_SIZE;		//文件块数
	if( nChunkCount == 0 || FileLen % nChunkCount != 0) {
		nChunkCount++;
	}

	//MIAN SEND
	send(client_sock,(char*)&FileLen,sizeof(int),0);		//向客户端发送文件长度
	for(int i = transPos;i < nChunkCount;i++)		//从断点处分块发送
	{
		int nSendSize = 0;		//将要发送的数据大小
		if(i + 1 == nChunkCount) {		//最后一块
			nSendSize = FileLen - CHUNK_SIZE * ( nChunkCount - 1 );
		}else {
			nSendSize = CHUNK_SIZE;
		}

		char *data = (char*)malloc(sizeof(char) * nSendSize);		//分配存放当前读取的文件空间
		memset(data,0,nSendSize);
		int idx=0;
		int rdLens = fread(data,sizeof(char),nSendSize,theFile);
		if( nSendSize != rdLens+1) {		//判断是否读取额定大小的文件内容
			printLine("read len != send len");
			break;
		};

		int ret = 0;		//判断socket是否正常
		while(nSendSize > 0) {
			ret = send(client_sock,&data[idx],nSendSize,0);
			if(ret < 1) {
				errorLine("Send The Date end");
				break;
			}
			nSendSize -= ret;
			idx += ret;
		}
		free(data);

		if(ret == -1) {
			printLine("The connection is closed.");
			break;
		}else {
			printLine("Sending %d\%.",((i + 1)/nChunkCount * 100) );
		}

	}
	fclose(theFile);
	close(client_sock);
	return NULL;
}

void* TransServer::recvFile(void *clientSock)
{
	int client_sock = *(int*)(clientSock);
	std::string tmpPath = "./";
	char * fparam = safeRecv(client_sock,sqlCheck);
	tmpPath.append(fparam);
	tmpPath.append(".tmp");
	int		FileLen = 0;	//本次接收文件长度
	int		nCurrentPos = 0;	//断点位置
printLine("file is in");
	FILE*	PosFile  = fopen( tmpPath.c_str(),"r");	//*读取存储断点文件
	if(PosFile)	{	//*如果有临时文件则读取断点
		fread((char*)&nCurrentPos,sizeof(nCurrentPos),1,PosFile);	//*读取断点位置
		fclose(PosFile);
	}
	send(client_sock,(char*)&nCurrentPos,sizeof(int),0);	//*发送断点值

	if( recv(client_sock,(char*)&FileLen,sizeof(FileLen),0) != 0)	//*本次接收文件长度
	{
		if(FileLen > 0)
		{
			int	nChunkCount;	//本次接收的块数
			nChunkCount = FileLen / CHUNK_SIZE;	//计算文件块数
			if(nChunkCount == 0 || FileLen % nChunkCount != 0)	//若文件不能整分
			{
				nChunkCount++;
			}
			FILE *file = fopen(fparam,"ab");
			if(file)
			{
				fseek(file,(long)(nCurrentPos * CHUNK_SIZE),SEEK_SET);
				long seekpos = nCurrentPos;		//记录接收到的文件的大小
				for(int i = nCurrentPos;i < nChunkCount;i++)        //从断点处开始写入文件
				{
					int nRecvSize = 0;
					if(i+1 == nChunkCount) {	//最后一块
						nRecvSize = FileLen - CHUNK_SIZE * ( nChunkCount - 1 );
					}
					else {
						nRecvSize = CHUNK_SIZE;
					}
					char *data = (char*)malloc(sizeof(char) * nRecvSize);
					memset(data,0,nRecvSize);

					int idx=0;
					while(nRecvSize > 0)
					{
						int ret = recv(client_sock,&data[idx],nRecvSize,0);
						if(ret < 1) {
							errorLine("Recv Date Error.");
							break;
						}
						idx += ret;
						seekpos += ret;
						nRecvSize -= ret;
					}
					fwrite(data,sizeof(char),idx,file);
					free(data);

					FILE * PosFile = fopen(tmpPath.c_str(),"w");
					if(PosFile) {
						fwrite((char*)&seekpos,sizeof(long),1,PosFile);
						fclose(PosFile);
						if(idx == FileLen)
							remove(tmpPath.c_str());
					}
					printLine("received %d",idx);
				}
				fclose(file);
				file = NULL;
			}
		}

		printLine("receive end.");

	}
	close(client_sock);
	return NULL;
}

void* TransServer::PicRecv(void *clientSock)
{
	int client_sock = *(int*)(clientSock);

	std::string tmpPath = "./";
	char * fparam = safeRecv(client_sock,sqlCheck);
	tmpPath.append(fparam);
	tmpPath.append(".tmp");
	int		FileLen = 0;	//本次接收文件长度
	int		nCurrentPos = 0;	//断点位置
	printLine("file is in");
	FILE*	PosFile  = fopen( tmpPath.c_str(),"r");	//*读取存储断点文件
	if(PosFile)	{	//*如果有临时文件则读取断点
		fread((char*)&nCurrentPos,sizeof(nCurrentPos),1,PosFile);	//*读取断点位置
		fclose(PosFile);
	}
	send(client_sock,(char*)&nCurrentPos,sizeof(int),0);	//*发送断点值

	if( recv(client_sock,(char*)&FileLen,sizeof(FileLen),0) != 0)	//*本次接收文件长度
	{
		if(FileLen > 0)
		{
			int	nChunkCount;	//本次接收的块数
			nChunkCount = FileLen / CHUNK_SIZE;	//计算文件块数
			if(nChunkCount == 0 || FileLen % nChunkCount != 0)	//若文件不能整分
			{
				nChunkCount++;
			}
			FILE *file = fopen(fparam,"ab");
			if(file)
			{
				fseek(file,(long)(nCurrentPos * CHUNK_SIZE),SEEK_SET);
				long seekpos = nCurrentPos;		//记录接收到的文件的大小
				for(int i = nCurrentPos;i < nChunkCount;i++)        //从断点处开始写入文件
				{
					int nRecvSize = 0;
					if(i+1 == nChunkCount) {	//最后一块
						nRecvSize = FileLen - CHUNK_SIZE * ( nChunkCount - 1 );
					}
					else {
						nRecvSize = CHUNK_SIZE;
					}
					char *data = (char*)malloc(sizeof(char) * nRecvSize);
					memset(data,0,nRecvSize);

					int idx=0;
					while(nRecvSize > 0)
					{
						int ret = recv(client_sock,&data[idx],nRecvSize,0);
						if(ret < 1) {
							errorLine("Recv Date Error.");
							break;
						}
						idx += ret;
						seekpos += ret;
						nRecvSize -= ret;
					}
					fwrite(data,sizeof(char),idx,file);
					free(data);

					FILE * PosFile = fopen(tmpPath.c_str(),"w");
					if(PosFile) {
						fwrite((char*)&seekpos,sizeof(long),1,PosFile);
						fclose(PosFile);
						if(idx == FileLen)
							remove(tmpPath.c_str());
					}
					printLine("received %d",idx);
				}
				fclose(file);
				file = NULL;
			}
		}

		printLine("receive end.");

	}
	close(client_sock);
	return NULL;
}

void* TransServer::ScreenTrans( SocketManager * pSm )
{
	int recvLen = 0;
	int sendLen = 0;
	int m_sendFail = 0;
	SOCKLIST * Sender = NULL;
	SOCKLIST * pTemWork = NULL;
	SOCKLIST * pPre = NULL;
	std::string m_stotal;
	std::string m_zero = "00000000000000000000";
	char * buf = new char[DEFAULT_BUFLEN];
	memset(buf,'0',DEFAULT_BUFLEN);

	while(!pSm->GetLenth())
	{
		while(pTemWork != pSm->GetLast())  ///  接收所有Socket，找到发送者
		{
			if(pTemWork->m_fail == 5)pTemWork = pSm->DelElem(pTemWork->strArr);
			recvLen = recv(pTemWork->m_sock,buf,DEFAULT_BUFLEN,0);
			if(recvLen>0)
			{
				pTemWork->m_fail = 0;
				Sender = pTemWork;
				break;
			}
			if(recvLen<0)pTemWork->m_fail++;
			pTemWork = pTemWork->next;
			if(pTemWork == pSm->GetLast())
			{
				recvLen = recv(pTemWork->m_sock,buf,DEFAULT_BUFLEN,0);
				if(recvLen>0)
				{
					Sender = pTemWork;
					break;
				}
				else
				{
					pTemWork = pSm->GetFirst();
				}
			}			
		}
		memcpy(m_stotal,buf,recvLen);
		while(m_stotal.length())
		{
			if(strncmp("all",buf,3))continue;
			if(recvLen>0)pSm->SendExcept(Sender->strArr,buf,recvLen);
			memset(buf,'0',DEFAULT_BUFLEN);
			if((recvLen = recv(Sender->m_sock,buf,DEFAULT_BUFLEN,0))<=0)
			{
				m_sendFail++;
				if(m_sendFail - 5)break;
				continue;
			}
			m_sendFail = 0;
		}
	}
}