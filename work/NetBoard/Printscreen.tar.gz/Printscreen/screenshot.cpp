
#include <QtGui>

#include "screenshot.h"

Screenshot::Screenshot()
{
    screenshotLabel = new QLabel;
    screenshotLabel->setSizePolicy(QSizePolicy::Expanding,
                                   QSizePolicy::Expanding);
    screenshotLabel->setAlignment(Qt::AlignCenter);
    screenshotLabel->setMinimumSize(480, 320);

    createOptionsGroupBox();

    createButtonsLayout();

    mainLayout = new QVBoxLayout;
    mainLayout->addWidget(screenshotLabel);
    mainLayout->addWidget(optionsGroupBox);
    mainLayout->addLayout(buttonsLayout);
    setLayout(mainLayout);

    shootScreen();

    delaySpinBox->setValue(5);

    setWindowTitle(tr("Screenshot"));
    resize(300, 200);
}


/*

在构造函数中，我们首先创建的QLABEL显示截图预览。

我们设置QLABEL的大小政策是QSizePolicy的::水平和垂直扩展。这意味着，QLABEL的尺寸暗示是一个合理的大小，
但收缩的插件可以仍然是有用的。另外，窗口小部件可以利用的额外空间，所以它应该尽可能获得尽可能多的空间。
然后我们确保QLABEL截图小工具的中心对齐，并设置其最小尺寸。

我们创建的应用程序的按钮和组框，其中包含应用程序的选项，并把它变成一个主要布局。最后，我们把最初的截图，
和设置>初始的的延迟和窗口标题之前，我们调整到一个合适的尺寸小部件。

 */









void Screenshot::resizeEvent(QResizeEvent * )
{
    QSize scaledSize = originalPixmap.size();
    scaledSize.scale(screenshotLabel->size(), Qt::KeepAspectRatio);
    if (!screenshotLabel->pixmap() || scaledSize != screenshotLabel->pixmap()->size())
        updateScreenshotLabel();
}


/*

重新实现resizeEvent（）函数接收派遣到部件的resize事件。其目的是为了扩展其内容不变形，画面像素图，并确保应用程序可以顺利被调整。

为了实现第一个目标，我们扩展的截图像素图使用Qt :: KeepAspectRatio。我们缩放像素映射到一个矩形尽可能大的电流大小的截图预览标签里面，
 保持长宽比。这意味着，如果用户改变应用程序窗口的大小，只在一个方向，在预览屏幕截图保持相同的大小。

要达到我们的第二个目标，我们要确保画面重绘（使用私人updateScreenshotLabel（）函数）时，它实际上改变其大小。

*/









void Screenshot::newScreenshot()
{
    if (hideThisWindowCheckBox->isChecked())
        hide();
    newScreenshotButton->setDisabled(true);

    QTimer::singleShot(delaySpinBox->value() * 1000, this, SLOT(shootScreen()));
}

  /*

    的私人newScreenshot（）插槽称为当用户请求一个新的截图，但插槽只准备一个新的截图。

    首先，我们看是否隐藏此窗口选项被选中，如果它是我们隐藏截图小工具。然后我们禁用新的屏幕截图按钮，以确保用户只能申请一次截图。

    我们创建了一个定时器使用QTimer的类，它提供重复和单次定时器。我们设置定时器超时，只有一次，使用静态QTimer的::的单张，
  （）的功能。此功能调用私有shootScreen，截图延迟选项所指定的时间间隔后（）槽。这是shootScreen（），实际执行的截图。

  */

void Screenshot::saveScreenshot()
{
    QString format = "png";
    QString initialPath = QDir::currentPath() + tr("/untitled.") + format;

    QString fileName = QFileDialog::getSaveFileName(this, tr("Save As"),
                               initialPath,
                               tr("%1 Files (*.%2);;All Files (*)")
                               .arg(format.toUpper())
                               .arg(format));
    if (!fileName.isEmpty())

        originalPixmap.save(fileName, format.toAscii());

}
/*
    槽被称为saveScreenshot（），当用户按下“保存”按钮，它提出了一个文件对话框使用QFileDialog中类。

    QFileDialog中使得用户能够遍历，以便选择一个或多个文件或目录的文件系统。 QFileDialog中创建一个最简单的方法是使用的方便的静态函数。

    我们定义的默认文件格式为PNG，文件对话框的初始路径的路径运行应用程序时。我们创建的文件对话框中使用静态QFileDialog中::的则GetSaveFileName（）
    函数返回一个文件名，由用户选择。该文件不存在。如果文件名是有效的，我们使用的QPixmap ::保存（）函数在该文件中保存截图的原始像素图。

*/

void Screenshot::shootScreen()
{
    if (delaySpinBox->value() != 0)
        qApp->beep();
    originalPixmap = QPixmap(); // clear image for low memory situations
                                // on embedded devices.
    originalPixmap = QPixmap::grabWindow(QApplication::desktop()->winId());
    updateScreenshotLabel();

    newScreenshotButton->setDisabled(false);

    if (hideThisWindowCheckBox->isChecked())
        show();
}

   /*
    我们使用静态的QPixmap :: grabWindow（）函数的截图。功能抓住作为参数传递的窗口的内容，使得一个像素映射出它和像素图回报。

    我们将参数标识使用QWidget的窗口:: winID（）函数返回窗口系统标识符。在这里，它返回的 - 标识符的QApplication检索当前QDesktopWidget，
 ::桌面（）函数。 QDesktopWidget类提供获取屏幕信息，和继承QWidget的:: winID（）。

    我们更新的截图预览标签的私人updateScreenshotLabel（）函数。然后我们启用新的截图按钮，最后我们做截图小工具，如果它是隐藏在截图可见。

       */








void Screenshot::updateCheckBox()
{
    if (delaySpinBox->value() == 0) {
        hideThisWindowCheckBox->setDisabled(true);
        hideThisWindowCheckBox->setChecked(false);
    }
    else
        hideThisWindowCheckBox->setDisabled(false);
}
     /*
        隐藏这个窗口选项启用或禁用取决于延迟的截图。如果没有延迟，应用程序窗口不能被隐藏和禁用选项的复选框。

        被称为updateCheckBox（）槽，当用户改变使用截图延迟选项延迟。

*/









void Screenshot::createOptionsGroupBox()
{
    optionsGroupBox = new QGroupBox(tr("Options"));

    delaySpinBox = new QSpinBox;
    delaySpinBox->setSuffix(tr(" s"));
    delaySpinBox->setMaximum(60);
    connect(delaySpinBox, SIGNAL(valueChanged(int)), this, SLOT(updateCheckBox()));

    delaySpinBoxLabel = new QLabel(tr("Screenshot Delay:"));

    hideThisWindowCheckBox = new QCheckBox(tr("Hide This Window"));

    optionsGroupBoxLayout = new QGridLayout;
    optionsGroupBoxLayout->addWidget(delaySpinBoxLabel, 0, 0);
    optionsGroupBoxLayout->addWidget(delaySpinBox, 0, 1);
    optionsGroupBoxLayout->addWidget(hideThisWindowCheckBox, 1, 0, 1, 2);
    optionsGroupBox->setLayout(optionsGroupBoxLayout);
}
/*

    的私人createOptionsGroupBox（）函数被调用的函数。

    首先，我们创建一个组框将包含所有选项“部件。然后，我们创建一个QSpinBox和QLABEL的的截图延迟选项，纺纱箱连接在updateCheckBox（）槽。
    最后，我们创建一个QCheckBox隐藏此窗口选项，所有选项部件的QGridLayout和安装组框上的布局。

    需要注意的是我们没有指定任何父母的部件，当我们创建它们。其原因是，当我们添加一个部件的布局并安装另一个插件上的布局
   该布局的窗口小部件会自动的父窗口小部件的布局上安装。

 */




void Screenshot::createButtonsLayout()
{
    newScreenshotButton = createButton(tr("New Screenshot"),this, SLOT(newScreenshot()));


    saveScreenshotButton = createButton(tr("Save Screenshot"), this, SLOT(saveScreenshot()));


    quitScreenshotButton = createButton(tr("Quit"), this, SLOT(close()));

    buttonsLayout = new QHBoxLayout;

    buttonsLayout->addStretch();

    buttonsLayout->addWidget(newScreenshotButton);
    buttonsLayout->addWidget(saveScreenshotButton);
    buttonsLayout->addWidget(quitScreenshotButton);
}
/*

 的私人createButtonsLayout（）函数被调用的函数。我们使用的私人createButton（）函数创建应用程序的按钮，并把它们添加到QHBoxLayout。

*/



QPushButton *Screenshot::createButton(const QString &text, QWidget *receiver,
                                      const char *member)
{
    QPushButton *button = new QPushButton(text);

    button->connect(button, SIGNAL(clicked()), receiver, member);
    return button;
}
/*
从createButtonsLayout（）函数的的私人createButton（）函数被调用。它只是创建了一个QPushButton提供的文本，
它连接到所提供的接收器和插槽，并返回一个指针按钮。
*/



void Screenshot::updateScreenshotLabel()
{
    screenshotLabel->setPixmap(originalPixmap.scaled(screenshotLabel->size(),
                                                     Qt::KeepAspectRatio,
                                                     Qt::SmoothTransformation));
}


 /*   的私人updateScreenshotLabel（）函数被调用的截图改变时，或resize事件时的截图预览标签的大小改变。
    更新的截图预览的标签的QLABEL :: setPixmap（）的QPixmap ::规模（）函数。

    规模的QPixmap ::（）返回给定的像素图的副本缩放到一个给定大小的矩形，根据给定的Qt :: AspectRatioMode和Qt :: TransformationMode。

    缩放原始的pixmap，以适应当前的屏幕截图标签的大小，保持长宽比，给所得的pixmap平滑的边缘。
    */
