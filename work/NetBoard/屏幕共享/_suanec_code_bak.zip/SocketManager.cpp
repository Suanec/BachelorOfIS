#include "SocketManager.h"

SocketManager::SocketManager(void)
{
	pFirst = NULL;                          
	pLast = NULL;                                   
	pPre = NULL;    
	pWork = NULL;
	len = 0;                                      
}

SocketManager::~SocketManager(void)
{
	while(pFirst!=pLast&&len)
	{
		pPre = pFirst;
		pFirst = pFirst->next;
		//close(pPre->m_sock);
		pPre->next = NULL;
		free(pPre);
		len--;
	}
	pLast = NULL;
	free(pFirst);
	pFirst = NULL;
	pPre = NULL;
	pWork = NULL;
	len = 0;
}

SOCKLIST * SocketManager::Search( std::string _target )
{
	if(!len)return NULL;
	SOCKLIST * pTemWork = pFirst;
	while(_target.compare(pTemWork->strArr))
	{
		if(! pTemWork->next)return NULL;
		pTemWork = pTemWork->next;
	}
	return pTemWork;
}
SOCKLIST * SocketManager::DelElem( std::string _target )
{

	if(!len)return NULL;
	SOCKLIST * pTemWork = pFirst;
	pPre = pFirst;
	if(!_target.compare(pTemWork->strArr))/// ��һ������ɾ����Ԫ��
	{
		pPre = pFirst->next;
		pFirst = pPre;
		pTemWork->next = NULL;
		//close(pTemWork->m_sock);
		free(pTemWork);
		return pPre;
	}
	pTemWork = pFirst->next;///  ��һ��������ɾ��Ԫ��
	while(_target.compare(pTemWork->strArr))///  ��Ԫ��
	{
		if(! pTemWork->next)break;
		pPre = pTemWork;
		pTemWork = pTemWork->next;
	}
	if(pTemWork != pLast )  ///  ���˳�ѭ����������Ԫ��
	{
		pPre->next = pTemWork->next;
		pTemWork->next = NULL;
		//close(pTemWork->m_sock);
		free(pTemWork);
		pTemWork = NULL;
		return pPre->next;
	}
	if(_target.compare(pTemWork->strArr))return NULL;///  ���һ��Ԫ�ز�������Ԫ��
	pPre->next = NULL;
	pLast = pPre;
	//close(pTemWork->m_sock);
	free(pTemWork);
	pTemWork = NULL;
	return pPre;
}
int SocketManager::SendToID( std::string _target,char * pData, int DataLen )
{
	int ret = 0;
	SOCKLIST * TarLinkNode = Search(_target);
	if(!TarLinkNode)return TarLinkNode->m_sock;
	//ret = send(TarLinkNode->m_sock,pData,DataLen,0);
	return ret;
}
SOCKLIST * SocketManager::SendToAll( char * pData, int DataLen )
{
	pWork = pFirst;
	while(pWork != pLast)
	{
		if(/*send(pWork->m_sock,pData,DataLen,0) <= */0) 
		{
			pWork->m_fail++;
			if(!(pWork->m_fail-5))
			{
				std::string _t = std::string(pWork->strArr);
				pWork = pWork->next;
				DelElem(_t);
			}
			continue;
		}
		pWork->m_fail = 0;
		pWork = pWork->next;
	}
	//send(pWork->m_sock,pData,DataLen,0);
	return pWork;
}
SOCKLIST * SocketManager::SendExcept( std::string _IDName ,char * pData, int DataLen )
{
	pWork = pFirst;
	while(pWork!=pLast)
	{
		if(! _IDName.compare(std::string(pWork->strArr)))
		{
			pWork = pWork->next;
			continue;
		}
		if(0/*send(pWork->m_sock,pData,DataLen,0) <= 0*/) 
		{
			pWork->m_fail++;
			if(!(pWork->m_fail-5))
			{
				std::string _t = std::string(pWork->strArr);
				pWork = pWork->next;
				DelElem(_t);
			}
			continue;
		}
		pWork->m_fail = 0;
		pWork = pWork->next;
	}
	//send(pWork->m_sock,pData,DataLen,0);
	return pWork;
}
bool SocketManager::AddHead( SOCKLIST * _ele )
{
	if(!pFirst)
	{
		pFirst = _ele;
		pLast = pFirst;
		len ++;
		return true;
	}
	SOCKLIST * pTemWork = _ele;
	pTemWork->next = pFirst;
	pFirst = pTemWork;
	len ++ ;
	return true;
}
bool SocketManager::AddHead( int _sk, std::string _ID)
{
    SOCKLIST * pTemWork ;
	if(!(pTemWork = (SOCKLIST*)malloc(sizeof(SOCKLIST))))return false;
	//pTemWork->m_ID = _ID;
	memset(pTemWork->strArr,0,ARRAYSIZE);
	memcpy(pTemWork->strArr,_ID.c_str(),_ID.length());
	pTemWork->m_arrlen = _ID.length();

	pTemWork->m_fail = 0;
	pTemWork->m_sock = _sk;
	//pTemWork->thread = _td;
	pTemWork->next = NULL;
	return AddHead(pTemWork);
}
