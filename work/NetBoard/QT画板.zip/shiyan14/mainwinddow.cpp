#include"mainwindow.h"
#include<QtGui>
//#include<QPen>
MainWindow::MainWindow()
{
    w=5;
    flag = false;
    setAttribute(Qt::WA_DeleteOnClose);
    setWindowTitle(tr("drawing board"));
    setFixedSize(800,600);
    image = QImage(this->width(),this->height(),QImage::Format_RGB32);
    tempimage = QImage(this->width(),this->height(),QImage::Format_RGB32);
    image.fill(~0x0);
    createActions();
    createMenus();
    createToolBar();
}

void MainWindow::createActions()
{
    OpenAction = new QAction(QIcon(":/images/open.png"),tr("Open"),this); //�򿪶���
    OpenAction->setShortcut(tr("Ctrl+O"));
    OpenAction->setStatusTip(tr("open a file"));
    connect(OpenAction,SIGNAL(triggered()),this,SLOT(slotOpenFile()));

    NewAction = new QAction(QIcon(":/images/new.png"),tr("New"),this);//�½�����
    NewAction->setShortcut(tr("Ctrl+N"));
    NewAction->setStatusTip(tr("new file"));
    connect(NewAction,SIGNAL(triggered()),this,SLOT(slotNewFile()));

    SaveAction = new QAction(QPixmap(":/images/save.png"),tr("Save"),this); //���涯��
    SaveAction->setShortcut(tr("Ctrl+S"));
    SaveAction->setStatusTip(tr("save file"));
    connect(SaveAction,SIGNAL(activated()),this,SLOT(slotSaveFile()));

    exitAction = new QAction(tr("Exit"), this);//�˳�����
    exitAction->setShortcut(tr("Ctrl+Q"));
    exitAction->setStatusTip(tr("exit"));
    connect(exitAction, SIGNAL(triggered()), this, SLOT(close()));


    aboutAction = new QAction(tr("About"), this);
    connect(aboutAction, SIGNAL(triggered()), this, SLOT(slotAbout()));

    lineAction = new QAction(QIcon(":/images/zhixian.png"),tr("line"),this);//����
    lineAction->setStatusTip(tr("draw a line"));
    connect(lineAction,SIGNAL(triggered()),this,SLOT(drawlines()));

    rectAction = new QAction(QIcon(":/images/juxing.png"),tr("rect"),this); //������

    rectAction->setStatusTip(tr("draw a rect"));
    connect(rectAction,SIGNAL(triggered()),this,SLOT(drawrects()));

    ellipseAction = new QAction(QIcon(":/images/yuan.png"),tr("circle"),this);//��Բ
    ellipseAction->setStatusTip(tr("draw a ellipse"));
    connect(ellipseAction,SIGNAL(triggered()),this,SLOT(drawellipses()));

    penAction = new QAction(QIcon(":/images/huabi.png"),tr("pen"),this);//����
    penAction->setStatusTip(tr("draw anything"));
    connect(penAction,SIGNAL(triggered()),this,SLOT(drawpen()));

    eraserAction = new QAction(QIcon(":/images/xiangpica.png"),tr("eraser"),this);//��Ƥ��
    eraserAction->setStatusTip(tr("clean image"));
    connect(eraserAction,SIGNAL(triggered()),this,SLOT(draweraser()));



}
void MainWindow::createMenus()//�����˵�
{
    fileMenu = menuBar()->addMenu(tr("File"));
    aboutMenu = menuBar()->addMenu(tr("Help"));

    fileMenu->addAction(NewAction);
    fileMenu->addAction(OpenAction);
    fileMenu->addAction(SaveAction);
    fileMenu->addSeparator();
    fileMenu->addAction(exitAction);



    aboutMenu->addAction(aboutAction);
}

void MainWindow::createToolBar()//����������
{
    fileTool = addToolBar(tr("file"));
    fileTool->addAction(NewAction);
    fileTool->addAction(OpenAction);
    fileTool->addAction(SaveAction);
    fileTool->addSeparator();

    paintTool = addToolBar(tr("Paint"));
    paintTool->addAction(lineAction);
    paintTool->addAction(rectAction);
    paintTool->addAction(ellipseAction);
    paintTool->addAction(penAction);
    paintTool->addAction(eraserAction);

    lineLabel = new QLabel(tr("line color"));
    paintTool->addWidget(lineLabel);
    lineButton = new QToolButton();
    paintTool->addWidget(lineButton);
    lineButton->setPalette(QPalette(linecolor));
    lineButton->setAutoFillBackground(true);
    connect(lineButton,SIGNAL(clicked()),this,SLOT(drawPaletteline()));


    fillLabel = new QLabel(tr("fill color"));
    fillcolor.setRgb(255,255,255);
    paintTool->addWidget(fillLabel);
    fillButton = new QToolButton();
    paintTool->addWidget(fillButton);
    fillButton->setPalette(QPalette(fillcolor));
    fillButton->setAutoFillBackground(true);
    connect(fillButton,SIGNAL(clicked()),this,SLOT(drawPalettefill()));

 //   widthLabel = new QLabel();
  //  widthLabel->setPicture();
    spinbox = new QSpinBox();
    spinbox->setValue(5);
    spinbox->setRange(0,50);
    paintTool->addWidget(spinbox);
    connect(spinbox,SIGNAL(valueChanged(int)),this,SLOT(drawwidth()));


}

void MainWindow::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    if(flag==true)
    {
        painter.drawImage(0,50,tempimage);
    }
    else
    {
        painter.drawImage(0,50,image);
    }
}

void MainWindow::mouseMoveEvent(QMouseEvent *event)
{
    if(event->buttons()&Qt::LeftButton)
    {
  //     QPainter painter(&image);
        endPoint = event->pos();
        endPoint.setY(endPoint.y()-50);
        tempimage = image;
        if(type==pen||type==eraser)
        {
            paint(image);
        }
        else
        {
            paint(tempimage);
        }
    }
}

void MainWindow::mouseReleaseEvent(QMouseEvent *event)
{
    flag = false;
    if(type==line||type==rect||type==ellipse)
    {
        paint(image);
    }
}

void MainWindow::mousePressEvent(QMouseEvent *event)
{
    if(event->buttons()&Qt::LeftButton)
    {
        flag = true;

        startPoint=event->pos();
        startPoint.setY(startPoint.y()-50);
    }
}

void MainWindow::paint(QImage &image)//��ͼ����
{
    QPainter painter(&image);
    QPen apen;
    apen.setColor(linecolor);
    apen.setWidth(w);
    painter.setPen(apen);
    painter.setBrush(QBrush(fillcolor));
    switch(type)
    {
    case line:
        painter.drawLine(startPoint,endPoint);
        break;
    case rect:
        painter.drawRect(startPoint.x(),startPoint.y(),
                         (endPoint.x()-startPoint.x()),(endPoint.y()-startPoint.y()));

         break;
    case ellipse:
         painter.drawEllipse(startPoint,
                             (endPoint.x()-startPoint.x()),(endPoint.y()-startPoint.y()));

         break;
    case pen:
         painter.drawLine(startPoint,endPoint);
         startPoint = endPoint;
         break;
    case eraser:

         painter.eraseRect(startPoint.x(),startPoint.y(),w,w);
         startPoint = endPoint;
         break;
    }
    update();
}

void MainWindow::slotNewFile()
{
    MainWindow *newWin = new MainWindow();
    newWin->show();
}


void MainWindow::slotOpenFile()
{
    QString fileName = QFileDialog::getOpenFileName(this,tr("Open File"),
                                                        "/",
                                                tr("Images (*.png *.xpm *.jpg)"));

    image.load(fileName);
    update();
}

void MainWindow::slotSaveFile()
{
    QString fileName = QFileDialog::getSaveFileName(this,tr("Save File"),
                                                    "/",tr("Images(*.png *.xpm *.jpg"));
    image.save(fileName);
    update();

}



void MainWindow::slotAbout()
{
    QMessageBox::StandardButton help;
    help = QMessageBox::information(this,"QMessageBox","This is a Qt drawing board program",
                                    QMessageBox::Yes);

}

void MainWindow::drawlines()
{
    type = line;
}

void MainWindow::drawrects()
{
    type = rect;
}

void MainWindow::drawellipses()
{
    type = ellipse;
}

void MainWindow::drawpen()
{
    type = pen;
}
void MainWindow::draweraser()
{
    type = eraser;
}

void MainWindow::drawPaletteline() //����ɫ
{
    linecolor = QColorDialog::getColor(Qt::black,this);
    if(linecolor.isValid())
    {
        lineButton->setPalette(QPalette(linecolor));
        lineButton->setAutoFillBackground(true);
    }
}

void MainWindow::drawPalettefill()//���ɫ
{
    fillcolor = QColorDialog::getColor(Qt::white,this);
    if(fillcolor.isValid())
    {
        fillButton->setPalette(QPalette(fillcolor));
        fillButton->setAutoFillBackground(true);
    }
}

void MainWindow::drawwidth()//������Ƥ������������
{
    w = spinbox->value();
}
