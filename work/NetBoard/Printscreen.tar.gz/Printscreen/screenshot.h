#ifndef SCREENSHOT_H
 #define SCREENSHOT_H

 #include <QPixmap>
 #include <QWidget>

 class QCheckBox;
 class QGridLayout;
 class QGroupBox;
 class QHBoxLayout;
 class QLabel;
 class QPushButton;
 class QSpinBox;
 class QVBoxLayout;

 class Screenshot : public QWidget
 {
     Q_OBJECT

 public:
     Screenshot();

 protected:
     void resizeEvent(QResizeEvent *event);

 private slots:
     void newScreenshot();
     void saveScreenshot();
     void shootScreen();
     void updateCheckBox();

 private:
     void createOptionsGroupBox();
     void createButtonsLayout();
     QPushButton *createButton(const QString &text, QWidget *receiver,
                               const char *member);
     void updateScreenshotLabel();

     QPixmap originalPixmap;

     QLabel *screenshotLabel;
     QGroupBox *optionsGroupBox;
     QSpinBox *delaySpinBox;
     QLabel *delaySpinBoxLabel;
     QCheckBox *hideThisWindowCheckBox;

     QPushButton *newScreenshotButton;
     QPushButton *saveScreenshotButton;
     QPushButton *quitScreenshotButton;

     QVBoxLayout *mainLayout;
     QGridLayout *optionsGroupBoxLayout;
     QHBoxLayout *buttonsLayout;
 };

 #endif

/*
 截图类可以继承QWidget的是应用程序的主窗口部件。它显示的应用程序选项和预览的截图。

 我们重新实现QWidget的:: resizeEvent（）函数来确保预览的截图尺度得当，当用户调整应用程序部件。我们还需要一些私人插槽，方便的选项：

 newScreenshot（）槽准备一个新的截图。
 saveScreenshot（）槽保存最后的截图。
 shootScreen（）槽需要的屏幕截图。
 updateCheckBox（）插槽可启用或禁用隐藏此窗口选项。
 我们还宣布一些私人的功能：我们使用的createOptionsGroupBox（），createButtonsLayout（）和createButton（）函数时，我们构造部件。而我们所说的的私人updateScreenshotLabel（）函数，每当一个新的截图被当作或当resize事件改变的截图预览标签的大小。

 此外，我们需要保存截图的原始像素图。原因是，当我们的截图显示预览，我们需要扩展它的像素图，存储原来我们要确保在这个过程中，没有数据丢失。

 */
