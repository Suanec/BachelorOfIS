#include "QScreenShare.h"
#include "personalPage.h"

ScreenLabel::ScreenLabel( QWidget * parent , QString role)
{
	pPixmap = new QPixmap;
	pTimer = new QTimer(this);
	pThread = new QThread;
	pScreenSlotObj = new ScreenSlot;
	pScreenEmitObj = new ScreenEmit;
	pArrPix = new QByteArray;
	pBufPix = new QBuffer;
	isFull = false;
	isHost = SetIsHost(role);

	fullScreenViewDlg = new FullScreenView(this);
	fullScreenViewDlg->hide();
	pTcpSocket = new QTcpSocket;

	QString TemStr;
	TemStr = PersonalPage::getAccount().c_str();
	TemStr = TemStr.split(":").last();
	m_NameID = TemStr.split("@").first();
	m_ServIP = TemStr.split("@").last();
	pTcpSocket->connectToHost(QHostAddress(m_ServIP),SHARESCREENDEFAULTPORT);
	if(pTcpSocket->isValid())pTcpSocket->write( m_NameID.toUtf8() );

	screenShareLabel = new QDLabel( this );
	screenShareLabel->setSizePolicy(QSizePolicy::Expanding,
		QSizePolicy::Expanding);
	screenShareLabel->setAlignment(Qt::AlignCenter);
	screenShareLabel->setMinimumSize(480, 320);

	CreateOptionsGroupBox();
	CreateButtonsLayout();

	mainLayout = new QHBoxLayout;
	leftLayout = new QVBoxLayout;
	leftLayout->addWidget(optionsGroupBox);
	leftLayout->addLayout(buttonsLayout);
	mainLayout->addLayout(leftLayout);
	mainLayout->addWidget(screenShareLabel);
	parent->setLayout(mainLayout);
	timerDelay = 400;
	delaySpinBox->setValue(timerDelay);
	pScreenSlotObj->moveToThread(pThread); 
	///  ��ʱ����
	connect(pTimer, SIGNAL(timeout()), pScreenSlotObj, SLOT(TimeSlot()));
	///  ��ʱ����
	connect(pTimer,SIGNAL(timeout()),this,SLOT(TimeOutObjSlot()));
	///  ���������
	connect(pScreenSlotObj, SIGNAL(ScrLabUpdate()), this, SLOT(ScrLayUpdate()));
	///  ��������
	connect(pScreenSlotObj,SIGNAL(PixDataReady()),this,SLOT(SendPArrToRemote()));
	///  ���ͼ�ʱ��Ϣ�������ݣ�������ʾ
	connect(pScreenEmitObj,SIGNAL(EmitDataRev()),this,SLOT(ReadPendingDataToPArr()));
	///  ȫ���˳�
	connect(fullScreenViewDlg,SIGNAL(ExitFullScreen()),this,SLOT(ExitFullSlot()));
	///  ˫������
	connect(screenShareLabel,SIGNAL(QDLabelDClicked()),
		this,SLOT(mouseDoubleSlot()));
}

ScreenLabel::~ScreenLabel()
{
	pTimer->stop();
	pThread->exit();
	fullScreenViewDlg->hide();
}

void ScreenLabel::CreateOptionsGroupBox()
{
	optionsGroupBox = new QGroupBox(tr("Options"));
	delaySpinBox = new QSpinBox;
	delaySpinBox->setSuffix(tr("ms"));
	delaySpinBox->setMaximum(1499);
	delaySpinBoxLabel = new QLabel(tr("Screenshot Delay:"));
	optionsGroupBoxLayout = new QGridLayout;
	optionsGroupBoxLayout->addWidget(delaySpinBoxLabel, 0, 0);
	optionsGroupBoxLayout->addWidget(delaySpinBox, 1, 0);
	optionsGroupBox->setLayout(optionsGroupBoxLayout);
}

QPushButton *ScreenLabel::CreateButton(const QString &text, QWidget *receiver,
									   const char *member)
{
	QPushButton *button = new QPushButton(text);
	button->connect(button, SIGNAL(clicked()), receiver, member);
	return button;
}

void ScreenLabel::CreateButtonsLayout()
{
	startShareButton = CreateButton(tr("��ʼ����"),this,SLOT(shareScreenSlot()));
	stopShareButton = CreateButton(tr("ֹͣ����"),this,SLOT(stopShareSlot()));
	fullScreenButton = CreateButton(tr("ȫ����ʾ"),this, SLOT(FullScreenShow()));
	//quitScreenButton = CreateButton(tr("Quit"), this, SLOT(close()));
	buttonsLayout = new QVBoxLayout;
	buttonsLayout->addStretch();
	buttonsLayout->addWidget(startShareButton);
	buttonsLayout->addWidget(stopShareButton);
	buttonsLayout->addWidget(fullScreenButton);
	//buttonsLayout->addWidget(quitScreenButton);
}

void ScreenLabel::resizeEvent(QResizeEvent * )
{
	QSize scaledSize = pPixmap->size();
	scaledSize.scale(screenShareLabel->size(), Qt::KeepAspectRatio);
	if (!screenShareLabel->pixmap() || scaledSize != screenShareLabel->pixmap()->size())
		UpdateLabel();
}

void ScreenLabel::FullScreenShow()
{
	if(pThread->isRunning()&&pTimer->isActive())
	{
		fullScreenViewDlg->move(10,5);
		fullScreenViewDlg->show();
		isFull = true;
	}
}

bool ScreenLabel::SetIsHost(QString m_role)
{
	if(m_role == "1"||m_role == "3") return true;
	else return false;
}

void ScreenLabel::ScrLayUpdate()
{
	QByteArray *pBa = pScreenSlotObj->GetByteArray();
	(( isFull )
		? (fullScreenViewDlg->UpdateFullScreenLabel(pBa)) 
		: (UpdateLabel(pBa)));
}

void ScreenLabel::UpdateLabel(QByteArray * pBa)
{
	pPixmap->loadFromData(*pBa,"JPEG");
	UpdateLabel();

}

void ScreenLabel::UpdateLabel()
{
	screenShareLabel->setPixmap(pPixmap->scaled(screenShareLabel->size(),
		Qt::KeepAspectRatio,
		Qt::SmoothTransformation));
	//screenShareLabel->repaint();
	screenShareLabel->update();
}

void ScreenLabel::SendPArrToRemote()              ///  ����ѹ���õĽ�ͼ��Ϣ
{
	if(isHost)
	{
		QByteArray * pSendData = pScreenSlotObj->GetByteArray();
        this->SendPixData( pTcpSocket, pSendData, pSendData->length(), "all");
	}
	else
	{
		ReadPendingDataToPArr();
	}

	///  Send pSendData->data() to Server.
}

void ScreenLabel::ReadPendingDataToPArr()         ///  ����Զ�����ݲ������ػ溯��
{
	/// pSocket->readData(pArrPix->data());
	if(isHost)return;
	if(pTcpSocket->isValid()&&pTcpSocket->bytesAvailable())
	{
		free(pArrPix);
		pArrPix = new QByteArray;
		pArrPix->resize(pTcpSocket->bytesAvailable());
		this->RecvPixData(pTcpSocket, pArrPix);
		(( isFull )
			? (fullScreenViewDlg->UpdateFullScreenLabel(pArrPix)) 
			: (UpdateLabel(pArrPix)));
	}
}

int ScreenLabel::SendPixData( QTcpSocket * pSOCK = NULL,
							 QByteArray * pARR = NULL, 
							 int len = 0, 
							 QString DestRoleStr = "all" )
{
	int sum = 0;                               ///  the total lenth sended.
	char * pIndex = NULL;                      ///  the position that should send next time.
	char * pTemTail = NULL ;                   ///  the position that the peer's tail.
	int ret = 0;	                           ///  is the socket aviliable?
	if(pSOCK) return -1;

	if(pARR)pIndex = pARR->data();
	if(pIndex)pTemTail = pIndex;

	if (!pIndex||!len)return -1;

	if(pSOCK->write("revPic",sizeof("revPic")) <= 0) return 0;
	if(pSOCK->write(DestRoleStr.toUtf8()) <= 0) return 0;

	if(pIndex)
	{
		if( ( len - sum ) == 0 )return sum;
		while( sum < len ) 
		{
			((len-sum)>PEER_DEFAULT_SIZE)?
				(ret = pSOCK->write(pIndex, PEER_DEFAULT_SIZE))
				:(ret = pSOCK->write( pIndex, (len-sum) ));
			pSOCK->flush();
			if(ret<0)return ret;
			sum += (ret/ONE);
			pIndex += (ret/ONE);
		}
	}
	
	if(sum == len) return sum;
	else return -1;
}

int ScreenLabel::RecvPixData( QTcpSocket * pSOCK = NULL,
							 QByteArray * pARR = NULL, 
							 QString SrcRoleStr)
{
	char * pIndex = NULL ;                            ///  the position that read the coming data.
	int len;                                          ///  the data lenth.
	int sum;                                          ///  the lenth received.
	int ret;                                          ///  is the socket aviliable.
	if(pSOCK) return -1;                              

	pIndex = pARR->data();
	len = sum = ret = 0;
	if( pSOCK->write("downPic",sizeof("downPic")) <= 0 ) return -1;

	if( !pSOCK->read((char*)&len,sizeof(len))) return -1;
	if(!len) return -1;
	
	if(pIndex)
	{
		while( sum < len )
		{
			( (len-sum) < PEER_DEFAULT_SIZE )?
				(ret = pSOCK->read(pIndex, (len-sum)))
				:(ret = pSOCK->read(pIndex,PEER_DEFAULT_SIZE));
			if(ret<0)return ret;
			sum += ret;
			pIndex += (ret/ONE);
		}
	}
	if(sum == len) return sum;
	else return -1;
}

void ScreenLabel::TimeOutObjSlot()
{
	/// if(pSocket->hasPendingDatagrams())
	    pScreenEmitObj->EmitDataRev();
}

void ScreenLabel::shareScreenSlot()
{
	pThread->start(); 
	pTimer->start(this->delaySpinBox->value());
}

void ScreenLabel::stopShareSlot()
{
	pTimer->stop();
	pThread->exit();
	fullScreenViewDlg->hide();
}

void ScreenLabel::ExitFullSlot()
{
	isFull = false;
}


void ScreenLabel::mouseDoubleSlot()
{
	FullScreenShow();
}

                  
